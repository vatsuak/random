// example.cpp

#include <tensorflow/core/platform/env.h>
#include <tensorflow/core/public/session.h>
#include <tensorflow/core/protobuf/meta_graph.pb.h>

#include <iostream>

using namespace std;
using namespace tensorflow;

int main()
{   //change the path to the .meta file
	const string path = "/home/vatsuak/Desktop/ramdom_practice/tf_cpp_test/";
	const string pathToGraph = path + "-300.meta";
	// const string checkpointPath = path + "models";

    Session* session;
    Status status = NewSession(SessionOptions(), &session);
    if (!status.ok()) {
        cout << status.ToString() << "\n";
        return 1;
    }
    cout << "Session successfully created.\n";

	// Read in the protobuf graph we exported
	MetaGraphDef graph_def;
	status = ReadBinaryProto(Env::Default(), pathToGraph, &graph_def);
	if (!status.ok()) {
		throw runtime_error("Error reading graph definition from " + pathToGraph + ": " + status.ToString());
	}
    cout << "Graph read!\n";
    cout << "====================\n\n\n\n\n\n\n";

	// Add the graph to the session
	status = session->Create(graph_def.graph_def());
	if (!status.ok()) {
		throw runtime_error("Error creating graph: " + status.ToString());
	}
}